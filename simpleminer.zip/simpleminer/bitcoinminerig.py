import requests
import hashlib
import threading
import time
import json
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sockets import Sockets

# Configuration
CONFIG_FILE = "config.json"

with open(CONFIG_FILE, "r") as f:
    config = json.load(f)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///simple_miner.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = config['api_key']
db = SQLAlchemy(app)
limiter = Limiter(app, key_func=get_remote_address)
sockets = Sockets(app)

# Database Models
class MiningData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bitcoins_mined = db.Column(db.Integer, default=0)
    last_block_hash = db.Column(db.String(64), nullable=True)

# Initial Setup
db.create_all()
if MiningData.query.first() is None:
    db.session.add(MiningData())
    db.session.commit()

# Bitcoin Miner Class
class BitcoinMiner:
    def __init__(self):
        self.mining_data = MiningData.query.first()

    def mine(self, difficulty, server=None):
        nonce = 0
        prefix = '0' * difficulty
        while True:
            block = f"Block {self.mining_data.bitcoins_mined} Nonce: {nonce}"
            block_hash = hashlib.sha256(block.encode()).hexdigest()
            if block_hash.startswith(prefix):
                self.mining_data.bitcoins_mined += 1
                self.mining_data.last_block_hash = block_hash
                db.session.commit()
                return block_hash
            nonce += 1

miner = BitcoinMiner()

# Endpoints
@app.route('/mine', methods=['POST'])
@limiter.limit("5/minute")
def mine_bitcoin():
    api_key = request.headers.get('API-Key')
    if api_key != app.config['SECRET_KEY']:
        return jsonify({"error": "Invalid API Key"}), 401
    difficulty = request.json.get('difficulty', config['default_difficulty'])
    block_hash = miner.mine(difficulty)
    return jsonify({"block_hash": block_hash, "bitcoins_mined": miner.mining_data.bitcoins_mined})

@app.route('/status', methods=['GET'])
def status():
    return jsonify({
        "bitcoins_mined": miner.mining_data.bitcoins_mined,
        "last_block_hash": miner.mining_data.last_block_hash
    })

# Mining Client
def mine_with_servers(difficulty):
    servers = config["servers"]
    for server in servers:
        try:
            response = requests.post(
                f"{server}/mine",
                json={"difficulty": difficulty},
                headers={"API-Key": config['api_key']}
            )
            print(response.json())
        except requests.RequestException:
            print(f"Failed to connect to server: {server}")

# User Menu
def main_menu():
    while True:
        print("\nSimple Miner Menu")
        print("1. Mine Bitcoin")
        print("2. Check Bitcoins Mined")
        print("3. Exit")
        choice = input("Choose an option: ")

        if choice == '1':
            difficulty = int(input("Enter mining difficulty (number of leading zeros): "))
            mine_with_servers(difficulty)
        elif choice == '2':
            response = requests.get(f"{config['servers'][0]}/status")
            print(response.json())
        elif choice == '3':
            print("Exiting Simple Miner...")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == '__main__':
    threading.Thread(target=lambda: app.run(debug=False, use_reloader=False)).start()
    main_menu()
